// README
/*
<project>
Estella Langenhoven 
estellalang

INSTRUCTIONS
<explain what your program does and how to use it>
similar to the pong game or table tennis, this game displays a recreation of it. Once you press play
the game should start on its own. You must try and hit the tennis ball with the racket to prevent it
from hitting the floor. If you hit the floor your score will skyrocket. the goal of this game is to hit the ball
against the racket until you reach 100. You want to be able to build your score on your own before the score hits 100.
This game is mainly controlled by your mouse. It is used to move your racket which is the main component
to the game. If you try to "cheat" the game will catch up tp you and make the ball dissapear incidcating that you fail.


CODING QUALITY AND VISUAL DESIGN
<argue for your coding quality and visual design>
For this game I wanted to have the original aspects of table tennis within it but make it 
more visually appealing. Instead of having two rackets I decided to treate it as if you're 
playing tennis with yourself. The overall vision for this game was to give it a cute and
uplifting aesthic making it enjoyable and pleasing to the eye for players. I tried 
to choose shades that complimented eachother well as well as using cute characters to 
add to the game. What I'm most proud of is the visual aspect of the game, I drew the 
characters myself and decided to go with the overall theme of them having faces and
being smiley (i.e. tennis ball, hearts). In a way they're kind of like your little 
friends accompanying you on your game journey.


VIDEO
https://youtu.be/abWX5Gh9FmU

RELEASE
I Estella Langenhoven grant permission to CS 105 course staff to use
my Final Project program and video for the purpose of promoting CS 105.
<if you don't grant permission, erase the line above>
*/

// let statements & user-defined functions 
let game = true;
let x = [];
let y = [];
let ballx = 10;
let bally = 15;
let score = 0;
let bounceCount = 0;
let ball;
let racket;
let heart;
let bckg;
let bg_1;
let bg_2;
let i;

// best use of loading / displaying images
function preload() {
	ball = loadImage("tennisball.png");
	racket = loadImage("tennisracket.png");
	heart = loadImage("heart.png");
}

function setup() {
	createCanvas(770, 770);
	background(0);
	rectMode(CENTER);
	
	// arrays
	x[i] = 50;
	y[i] = 50;
	
	// background colours 
	bg_1 = color(255, 230, 238);
	bg_2 = color(229, 207, 251);
	bckg = bg_1;
	change = bg_2;
}

function draw() {

	background(bckg);
	drawGame();
} 


// user-defined function 
	function drawGame() {
	
	noStroke();

	// gameboard
	// best use of drawing shapes
	// best use of image processing
	image(heart, 175, 90, 25, 25) // left heart
	image(heart, 529, 7, 20, 20) // right heart
	image(ball, x[i], y[i], 50, 50);
	image(racket, mouseX, 650, 200, 50); // mouse / keyboard interaction 

	fill(255, 182, 193);
	textSize(20);
	text("Your Score:", 215, 110);
	text("Bounce Count:", 560, 25);
	textSize(120);
	text(score, 350, 120);
	textSize(20);
	text(bounceCount, 700, 25);


	// ball movement
	x[i] += ballx;
	y[i] += bally;


	// controls bounce and displays bounce count
	if (y[i] < 15 || y[i] > height - 15) {
		bally *= -1;
		bounceCount += 1;
	}
		
		// keeps in frame to bounce off walls
	if (x[i] > width - 15 || x[i] < 15) {
		ballx *= -1;
		bounceCount += 1;
	}

	// allows score to go up and keeps colours changing
	if (y[i] >= 650 && x[i] > mouseX - 63 &&
			x[i] < mouseX + 63) {
		bally *= -1;
		score += 1;


		// switches colour every time ball bounces
		// best use of loops
		if (bckg === bg_1) {
			bckg = bg_2;
			change = bg_1;
		} else {
			bckg = bg_1;
			change = bg_2;
		}
	}

	fill(change);

	// end game
	// best use of conditionals
	if (score === 100) { 
		game = false;
	}
if (game === false) {
	background(0);
	fill(255, 182, 193);
	textSize(50);
	text("end game!", 295, 350);
	}

	// score updates 
	// mouse/ keyboard interaction
	function keyPressed() {
		if (key === ' ') {
			score = 0;
		}
	}
}